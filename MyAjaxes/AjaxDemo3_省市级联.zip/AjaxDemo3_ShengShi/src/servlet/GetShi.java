package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetShi extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		response.setCharacterEncoding("UTF-8");
		String shandong = "jinan,qingdao";		
		String beijing = "朝阳区,海淀区";		//此处返回到jsp是出现了乱码，带解决。
		
		String temp = request.getParameter("sheng");
		String sheng = new String(temp.getBytes("ISO-8859-1"),"UTF-8");
		System.out.println(sheng);
		if(sheng.equals("山东省")){
			out.print(shandong);
		}
		else if(sheng.equals("北京市")){
			out.print(beijing);
		}
		else{
			out.print("==请选择市==");
		}
		out.flush();
		out.close();
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
