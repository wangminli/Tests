package svlt;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CheckUser extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
		
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		ArrayList<String> list = new ArrayList<String>();
		list.add("wangminli");
		list.add("liruiliang");
		String uname = request.getParameter("uname");
		boolean flag = false;
		for(String content:list){
			if(content.equals(uname)){
				flag = true;
			}
		}
		if(flag){
			out.println("<font color='red'>���û����ѱ�ע�ᣡ</font>");
		}
		else{
			out.println("<font color='green'>��ϲ�������û�������ע�ᣡ��</font>");
		}
		
			
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
